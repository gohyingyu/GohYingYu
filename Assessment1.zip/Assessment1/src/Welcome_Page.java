import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Welcome_Page implements ActionListener {
	JFrame frame = new JFrame();
	JLabel welcomeLabel = new JLabel("Hello!");
	JLabel messageLabel = new JLabel("Log In successful!");
	JButton restriWeb = new JButton("restricted webpage");
	JButton logoutBtn = new JButton("logout");
	
	
	Welcome_Page(String userID){
		
			welcomeLabel.setBounds(0,30,500,50);
			welcomeLabel.setFont(new Font(null,Font.PLAIN,25));
			messageLabel.setForeground(Color.green);
			messageLabel.setBounds(0,0,500,50);
			messageLabel.setFont(new Font(null,Font.PLAIN,25));
		
			logoutBtn.setBounds(250,0,180,35);
			logoutBtn.setFont(new Font(null,Font.ITALIC,25));
			
			restriWeb.setBounds(0,350,250,35);
			restriWeb.setFont(new Font(null,Font.ITALIC,25));
			
			welcomeLabel.setText("Welcome back "+userID);
			logoutBtn.setText("Logout");
			
			frame.add(welcomeLabel);
			frame.add(messageLabel);
			frame.add(logoutBtn);
			frame.add(restriWeb);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setSize(420, 420);
			frame.setLayout(null);
			frame.setVisible(true);
			restriWeb.addActionListener(this);
			logoutBtn.addActionListener(this);
		
			if(userID.equals("Goh"))
				{
					restriWeb.setVisible(true);
				}
			else {
					restriWeb.setVisible(false);
				}
			}

		public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==logoutBtn) {
			frame.dispose();
			Login_Page Login_Page = new Login_Page(null);
			
		}
	
		}
	}
