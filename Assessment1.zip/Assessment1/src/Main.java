
public class Main {
	
public static void main(String[] args) {
		
	ID_Pwd ID_Pwd = new ID_Pwd();
				
	Login_Page Login_Page = new Login_Page(ID_Pwd.getLoginInfo());

	}

}
