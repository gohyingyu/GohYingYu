import java.util.HashMap;

public class ID_Pwd {
	
	HashMap<String,String> logininfo = new HashMap<String,String>();
	
	ID_Pwd(){
		
		logininfo.put("Goh","123");
		logininfo.put("May","PASSWORD");
		logininfo.put("Ben","abc");

	}
	protected HashMap getLoginInfo(){
		return logininfo;
	}
}